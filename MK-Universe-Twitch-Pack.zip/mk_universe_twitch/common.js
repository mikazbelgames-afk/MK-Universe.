(function(){
  const body=document.body;
  for(let i=0;i<18;i++){
    const p=document.createElement('span'); p.className='petal';
    p.style.left=Math.random()*100+'vw';
    p.style.animationDuration=(8+Math.random()*10)+'s';
    p.style.animationDelay=(-Math.random()*12)+'s';
    p.style.transform='scale('+(0.6+Math.random()*0.9)+')';
    body.appendChild(p);
  }
})();
