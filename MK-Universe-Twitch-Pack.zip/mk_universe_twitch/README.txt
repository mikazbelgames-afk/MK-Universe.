MK Universe Twitch Mini-Pack

Archivos:
- inicio.html
- game.html
- chat.html
- canto.html
- brb.html
- fin.html
- styles.css
- common.js

Uso en GitHub Pages:
1. Sube la carpeta completa a tu repo, por ejemplo /twitch/
2. En OBS agrega Fuente de navegador.
3. Usa una URL como:
   https://mikazbelgames-afk.github.io/MK-Universe./twitch/inicio.html
4. Resolución recomendada: 1920x1080.

Notas:
- game.html tiene fondo transparente para superponerlo al juego.
- Las otras escenas sí incluyen fondo.
- Puedes editar textos directamente en cada HTML.
- Los colores principales están al inicio de styles.css.
